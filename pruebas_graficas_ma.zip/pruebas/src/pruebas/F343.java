package pruebas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.Box;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class F343 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblSecciones;
	private Component verticalStrut;
	private Component verticalStrut_1;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	private JMenuItem mntmNewMenuItem_2;
	private JButton btnOtros;
	private JPanel panel_1;
	private JSeparator separator;
	private JPanel panel_2;
	private JPanel panel_3;
	private JButton btnNewButton_6;
	private JButton btnNewButton_7;
	private JSeparator separator_1;
	private JLabel label_1;
	private JSeparator separator_2;
	private Component verticalStrut_2;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JButton btnVerReviews;
	private JButton btnHacerReview;
	private JButton button;
	private JButton button_1;
	private JLabel label;
	private JLabel label_5;
	private Component verticalStrut_3;
	private JTextField txtDescripcion;
	private JTextField textField_1;
	private JSeparator separator_3;
	private JSeparator separator_4;
	private JSeparator separator_5;
	private Component verticalStrut_4;
	private JPanel panel_4;
	private JRadioButton rdbtnGenero;
	private JRadioButton rdbtnGenero_1;
	private JRadioButton rdbtnGenero_2;
	private JRadioButton rdbtnGenero_3;
	private JRadioButton rdbtnGenero_4;
	private Component verticalStrut_5;
	private Component verticalStrut_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					F343 frame = new F343();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public F343() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 719, 514);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("$NombreUsuario");
		menuBar.add(mnNewMenu);
		
		mntmNewMenuItem = new JMenuItem("Ver mi perfil");
		mnNewMenu.add(mntmNewMenuItem);
		
		mntmNewMenuItem_1 = new JMenuItem("Ajustes");
		mnNewMenu.add(mntmNewMenuItem_1);
		
		mntmNewMenuItem_2 = new JMenuItem("Cerrar Sesion");
		mnNewMenu.add(mntmNewMenuItem_2);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		panel.setLayout(new MigLayout("", "[grow]", "[][][-5.00][][][-7.00][][][][][][][][][][][][][grow]"));
		
		textField = new JTextField();
		panel.add(textField, "flowx,cell 0 0,growx");
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Buscar");
		panel.add(btnNewButton, "cell 0 0");
		
		separator_3 = new JSeparator();
		separator_3.setForeground(Color.BLACK);
		panel.add(separator_3, "cell 0 2,growx");
		
		lblSecciones = new JLabel("SECCIONES");
		lblSecciones.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel.add(lblSecciones, "cell 0 3,alignx center");
		
		verticalStrut = Box.createVerticalStrut(20);
		panel.add(verticalStrut, "cell 0 1,grow");
		
		separator_4 = new JSeparator();
		separator_4.setForeground(Color.BLACK);
		panel.add(separator_4, "cell 0 4,growx");
		
		verticalStrut_1 = Box.createVerticalStrut(20);
		panel.add(verticalStrut_1, "cell 0 5 1 3,growx");
		
		btnNewButton_3 = new JButton("Peliculas");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		panel.add(btnNewButton_3, "cell 0 8,growx");
		
		btnNewButton_1 = new JButton("Series");
		panel.add(btnNewButton_1, "cell 0 9,growx");
		
		btnNewButton_4 = new JButton("Videojuegos");
		panel.add(btnNewButton_4, "cell 0 10,growx");
		
		btnNewButton_2 = new JButton("Musica");
		panel.add(btnNewButton_2, "cell 0 11,growx");
		
		btnNewButton_5 = new JButton("Libros");
		panel.add(btnNewButton_5, "cell 0 12,growx");
		
		btnOtros = new JButton("Otros");
		panel.add(btnOtros, "cell 0 13,growx");
		
		verticalStrut_4 = Box.createVerticalStrut(20);
		panel.add(verticalStrut_4, "cell 0 14,growx");
		
		separator_5 = new JSeparator();
		separator_5.setForeground(Color.BLACK);
		panel.add(separator_5, "cell 0 15,growx");
		
		panel_4 = new JPanel();
		panel.add(panel_4, "cell 0 16 1 3,grow");
		panel_4.setLayout(new MigLayout("", "[142.00]", "[][][][][]"));
		
		rdbtnGenero = new JRadioButton("Genero 1");
		panel_4.add(rdbtnGenero, "cell 0 0,alignx center");
		
		rdbtnGenero_1 = new JRadioButton("Genero 2");
		panel_4.add(rdbtnGenero_1, "cell 0 1,alignx center");
		
		rdbtnGenero_2 = new JRadioButton("Genero 3");
		panel_4.add(rdbtnGenero_2, "cell 0 2,alignx center");
		
		rdbtnGenero_3 = new JRadioButton("Genero 4");
		panel_4.add(rdbtnGenero_3, "flowy,cell 0 3,alignx center");
		
		rdbtnGenero_4 = new JRadioButton("Genero 5");
		panel_4.add(rdbtnGenero_4, "cell 0 4,alignx center");
		
		panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setOrientation(SwingConstants.VERTICAL);
		panel_1.add(separator, BorderLayout.WEST);
		
		panel_2 = new JPanel();
		panel_1.add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new MigLayout("", "[][266.00][]", "[-15.00][]"));
		
		separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		panel_2.add(separator_1, "cell 0 0 3 1,growx");
		
		btnNewButton_6 = new JButton("<-- Pagina Anterior");
		panel_2.add(btnNewButton_6, "cell 0 1");
		
		btnNewButton_7 = new JButton("Pagina Siguiente -->");
		panel_2.add(btnNewButton_7, "cell 2 1");
		
		panel_3 = new JPanel();
		panel_1.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new MigLayout("", "[][][199.00,grow][186.00,grow][85.00]", "[28.00][43.00][46.00][46.00][][][][42.00][47.00][][]"));
		
		verticalStrut_2 = Box.createVerticalStrut(20);
		panel_3.add(verticalStrut_2, "cell 1 0");
		
		label_3 = new JLabel("10/10");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 30));
		panel_3.add(label_3, "cell 3 2 1 2,alignx center");
		
		label = new JLabel("");
		label.setIcon(new ImageIcon("E:\\Florida\\PI\\1233.png"));
		panel_3.add(label, "cell 1 1 1 3");
		
		label_5 = new JLabel("TITULO");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 26));
		panel_3.add(label_5, "cell 2 1 3 1,alignx center");
		
		button_1 = new JButton("Ver Reviews");
		panel_3.add(button_1, "cell 4 2,grow");
		
		textField_1 = new JTextField();
		textField_1.setText("Descripcion");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		panel_3.add(textField_1, "cell 2 2 1 2,grow");
		
		button = new JButton("Hacer Review");
		panel_3.add(button, "cell 4 3,grow");
		
		verticalStrut_6 = Box.createVerticalStrut(20);
		panel_3.add(verticalStrut_6, "cell 1 4");
		
		separator_2 = new JSeparator();
		separator_2.setForeground(Color.BLACK);
		panel_3.add(separator_2, "cell 0 5 5 1,growx");
		
		verticalStrut_5 = Box.createVerticalStrut(20);
		panel_3.add(verticalStrut_5, "cell 1 6");
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("E:\\Florida\\PI\\1233.png"));
		panel_3.add(label_1, "cell 1 7 1 3");
		
		label_2 = new JLabel("TITULO");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 26));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel_3.add(label_2, "cell 2 7 3 1,alignx center");
		
		txtDescripcion = new JTextField();
		txtDescripcion.setText("Descripcion");
		txtDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
		txtDescripcion.setEditable(false);
		panel_3.add(txtDescripcion, "cell 2 8 1 2,grow");
		txtDescripcion.setColumns(10);
		
		label_4 = new JLabel("10/10");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 30));
		panel_3.add(label_4, "cell 3 8 1 2,alignx center");
		
		btnVerReviews = new JButton("Ver Reviews");
		panel_3.add(btnVerReviews, "cell 4 8,grow");
		
		btnHacerReview = new JButton("Hacer Review");
		panel_3.add(btnHacerReview, "cell 4 9,grow");
		
		verticalStrut_3 = Box.createVerticalStrut(20);
		panel_3.add(verticalStrut_3, "cell 1 10");
	
	}

}
