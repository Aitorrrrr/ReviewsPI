package pruebas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import net.miginfocom.swing.MigLayout;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Component;
import javax.swing.Box;
import java.awt.Toolkit;
import javax.swing.JSeparator;
import java.awt.Color;

public class R424 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JPasswordField passwordField;
	private JLabel lblNewLabel_2;
	private JButton btnNewButton;
	private JButton btnNuevoUsuario;
	private JButton btnNewButton_1;
	private Component verticalStrut;
	private Component verticalStrut_1;
	private JSeparator separator;
	private Component verticalStrut_3;
	private Component verticalStrut_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					R424 frame = new R424();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public R424() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\Florida\\PI\\423423.png"));
		setResizable(false);
		setTitle("Reviews y esas cosas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("E:\\Florida\\PI\\TEST.png"));
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[grow,fill][fill][200.00][fill][grow,fill]", "[][][][][][][][][][][][][][][]"));
		
		lblNewLabel_1 = new JLabel("EMAIL");
		panel.add(lblNewLabel_1, "cell 2 1,alignx center");
		
		textField = new JTextField();
		panel.add(textField, "cell 2 2,growx");
		textField.setColumns(10);
		
		lblNewLabel_2 = new JLabel("CONTRASE\u00D1A");
		panel.add(lblNewLabel_2, "cell 2 4,alignx center");
		
		passwordField = new JPasswordField();
		panel.add(passwordField, "cell 2 5,growx");
		
		verticalStrut_3 = Box.createVerticalStrut(20);
		panel.add(verticalStrut_3, "cell 2 6,grow");
		
		separator = new JSeparator();
		separator.setForeground(new Color(0, 0, 0));
		panel.add(separator, "cell 1 7 3 1,growx");
		
		verticalStrut_4 = Box.createVerticalStrut(20);
		panel.add(verticalStrut_4, "cell 2 8,grow");
		
		btnNewButton = new JButton("INICIAR SESION");
		panel.add(btnNewButton, "cell 2 9,growx");
		
		btnNuevoUsuario = new JButton("NUEVO USUARIO");
		panel.add(btnNuevoUsuario, "cell 2 10,growx");
		
		verticalStrut = Box.createVerticalStrut(20);
		panel.add(verticalStrut, "cell 2 11,growx,aligny center");
		
		verticalStrut_1 = Box.createVerticalStrut(20);
		panel.add(verticalStrut_1, "cell 2 12,growx");
		
		btnNewButton_1 = new JButton("No puedo iniciar sesion");
		panel.add(btnNewButton_1, "flowy,cell 2 14,growx");
	}
}
